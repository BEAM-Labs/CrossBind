import torch
import torch.nn as nn

import sparseconvnet as scn
from collections import Counter
import numpy as np
import torch.nn.functional as F  
import esm
import random
import math
from lightly.loss.ntx_ent_loss import NTXentLoss
def get_model(config):
    return SparseConvUnet(config)

def get_loss(config):
    return Loss(config)


class Loss(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        
    def forward(self,data_dict,device,aa_feature,aa_feature2,epoch,mode):
        loss_fun = torch.nn.BCELoss()
        loss = 0
        

        reg_pred = data_dict['residual']
        reg_labels = data_dict['reg_labels']
        reg_labels = reg_labels.unsqueeze(1)

        # label = []
        # # for i in data_dict['label_binary'][0]:
        # for i in data_dict['batch_label']:

        #     label.append(float(i))
        # label_binary = np.array(label)
        # label_tensor = torch.from_numpy(label_binary).unsqueeze(1)
        label_tensor = data_dict['batch_label'].unsqueeze(1)
        # reg_loss = self.config.regression.weight * \
        #         torch.nn.functional.smooth_l1_loss(reg_pred.squeeze(), reg_labels, size_average=True, reduce=True)
        ######## Atom level regression
        # reg_loss =  loss_fun(reg_pred.float(),reg_labels.float())
        ######### AA Level 
        reg_loss =  loss_fun(reg_pred.float(),label_tensor.float().to(device))#.cuda())

        # la = torch.ones(aa_feature.shape[0]).to(device)
        # aa_feature = aa_feature.reshape(-1)
        # aa_feature2 = aa_feature2.reshape(-1)
        # XXX = nn.CosineEmbeddingLoss(margin=0.2)
        # loss_new = XXX(aa_feature.to(device),aa_feature2.to(device),la)
        # loss_new = F.mse_loss(aa_feature, aa_feature2)
        # print(loss_new)
        # print(loss_new)
        # feature = torch.concat((aa_feature.unsqueeze(1),aa_feature2.unsqueeze(1)),1)
        # criterion = SupConLoss()
        # loss_new = criterion(feature,label_tensor.float().to(device))




        loss = reg_loss
        data_dict['reg_loss'] = reg_loss
        data_dict['label'] = reg_labels
        data_dict['binary_label'] = label_tensor
        if mode == 'self':
            criterion = NTXentLoss(temperature = 0.1).to(device)
            loss_new = criterion(aa_feature.to(device),aa_feature2.to(device))
            data_dict['loss'] =  loss_new
            # print('aaaa')
        else:
            data_dict['loss'] =  reg_loss 
            # print('fufufufufufuuf')
        # data_dict['loss'] =  loss

        return data_dict



class output_linear(nn.Module):
    def __init__(self):
        super().__init__()

        self.fc1 = nn.Linear(14*32, 1)
    
    def forward(self, data):
        out = self.fc1(data)
        output = torch.sigmoid(out)

        return output

class SparseConvUnet(nn.Module):
    def __init__(self, config):
        super().__init__()


        self.config = config
        m = config.m
        input_dim = 30 if config.use_coords else 27
        self.sparseModel = scn.Sequential().add(
           scn.InputLayer(3, config.full_scale, mode=config.mode)).add(
           scn.SubmanifoldConvolution(3, input_dim, m, 3, False)).add(
               scn.UNet(dimension=3,
                        reps=config.block_reps,
                        nPlanes=[m, 2*m, 3*m, 4*m, 5*m, 6*m, 7*m],
                        residual_blocks=config.block_residual,
                        )).add(
           scn.BatchNormReLU(m)).add(
           scn.OutputLayer(3))



        self.lstm = nn.LSTM(
            input_size=1088,# 传入我们上面定义的参数
            hidden_size=1280,# 传入我们上面定义的参数
            batch_first=True,# 为什么设置为True上面解释过了
        )

        if 'regression' in config:
            # self.fc1 = nn.Linear(14*m, 1)
            self.fc1 = nn.Linear(14*m, 1)
            self.fc2 = nn.Linear(128,64)
            self.fc3 = nn.Linear(64,1)
            self.dropout = torch.nn.Dropout(p=0.5)

            # self.project = nn.Sequential(
            #                 nn.Linear(14*32, 256, bias = False),
            #                 nn.BatchNorm1d(256),
            #                 nn.ReLU(inplace=True),
            #                 nn.Linear(256, 128, bias = False)
            #                 ) 

            self.project = nn.Sequential(
                nn.Linear(32, 32, bias = False),
                nn.BatchNorm1d(32),
                nn.ReLU(inplace=True),
                nn.Linear(32, 32, bias = False)
                ) 

            # self.attention = nn.Linear(448 , 14,bias=False)
        # self.attention2 = nn.Linear(6,14,bias=False)
            # self.embedding = nn.Linear(448, 448)





    def forward(self, data_dict,device,mode,mode_fc):
        
        # coords = np.ascontiguousarray(xyz - xyz.mean(0))
        # m = np.eye(3) + np.random.randn(3, 3) * 0.1
        # m[0][0] *= np.random.randint(0, 2) * 2 - 1
        # m /= 0.1

        # # rotation (currently only on z-axix)
        # theta = np.random.rand() * 2 * math.pi
        # m = np.matmul(m, [[math.cos(theta), math.sin(theta), 0], [-math.sin(theta), math.cos(theta), 0], [0, 0, 1]])
        # coords = np.matmul(coords, m)

        # # place on (0,0) and crop out the voxel outside the full_scale
        # m = coords.min(0)
        # M = coords.max(0)
        # fff = np.clip(4096 - M + m - 0.001, 0, None)
        # offset = - m + np.clip(4096 - M + m - 0.001, 0, None) * np.random.rand(3) + \
        #          np.clip(4096 - M + m + 0.001, None, 0) * np.random.rand(3)

        # coords += offset


        input_batch = [
            data_dict['coords'],
            data_dict['features']
        ]

        input_batch2 = [
            data_dict['coord2'],
            data_dict['features']
        ]

        feature = self.sparseModel(input_batch)
        feature2 = self.sparseModel(input_batch2).detach()
        # feature2 = feature
            

        if 'regression' in self.config:
            
            atom_num = data_dict['atom_num']
            label_binary = data_dict['label_binary']
            index = 0
            # aa_feature = torch.zeros(len(label_binary[0]) ,14 ,feature.shape[1])

            # aa_feature_mean = torch.zeros(len(label_binary[0])  ,feature.shape[1])
            # print('model^^^^^^^^^^^^')
            idn = 0
            final_feature = []
            final_feature2 = []
            final_label = []
            final_feature_attention = []            
        
            testa,testb = [],[]

            for z in (atom_num):
                idn += 1
                aa_feature = torch.zeros(len(z) ,14 ,feature.shape[1])
                aa_feature2 = torch.zeros(len(z) ,14 ,feature.shape[1])
                aa_feature_attention = torch.zeros(len(z) ,14 ,feature.shape[1])
                # aa_feature_mean = torch.zeros(len(z)  ,feature.shape[1])            
                j = 0
                
                for i in z:
                    aa_feature[j,:i,:] = feature[index:(index+i),:]
                    aa_feature2[j,:i,:] = feature2[index:(index+i),:]
                    
                        # threshold = random.randint(0, (i)+1)
                    # threshold = (random.sample(range(i), int((i)/2)))
                    # other = list(range(0,i))

                    # if mode =='train':
                    #     for xx in threshold:
                    #         aa_feature[j,xx,:] = 0
                    #         # testa.append(xx)
                    #     for ind in other:
                    #         if ind not in threshold:
                    #             aa_feature2[j,ind,:] = 0
                    #             # testb.append(ind)
                        


                    
                    # mea = (torch.mean(feature[index:(index+i),:] , 0)).unsqueeze(0)
                    # aa_feature_mean[j,:] = mea
                    # atom_wise = aa_feature[j,:].clone()
                    # attention_input = torch.flatten(atom_wise,0,1)
                    # attention_out = self.attention(attention_input.to(device))
                    # atom_par = torch.sigmoid(attention_out)
                    # after_attention = atom_par.unsqueeze(1) * atom_wise.to(device) 
                    # fee2 = torch.flatten(after_attention,0,1)
                    # att_out = self.embedding(fee2)
                    # att_out = att_out.reshape(14,32)

                    # aa_feature_attention[j,:] = att_out
                    index = index + i 
                    j += 1

                # final_feature_attention.append(aa_feature_attention)
                final_feature.append(aa_feature)
                final_feature2.append(aa_feature2)

                # final_feature.append(aa_feature_mean)
            feature_batch = torch.cat(final_feature , 0)
            amino_feature_mean = torch.mean(feature_batch,1).to(device)
            amino_feature = (torch.flatten(feature_batch,1,2)).to(device)


            feature_batch2 = torch.cat(final_feature2 , 0)
            amino_feature_mean2 = torch.mean(feature_batch2,1).to(device)
            amino_feature2 = (torch.flatten(feature_batch2,1,2)).to(device)

            # feature_batch_attention = torch.cat(final_feature_attention , 0)
            # aa_feature_attention = torch.flatten(feature_batch_attention,1,2)

            # out = self.fc1(amino_feature)#.cuda())
            # out = self.fc1(aa_feature_attention.to(device))#.cuda())

            # out = self.fc1(feature.to(device))#.cuda())
            # out = F.elu(self.fc1(aa_feature.to(device)))
            # out = F.elu(self.fc2(out))
            # output = torch.sigmoid(out)
            # output = torch.sigmoid(self.fc3(out))    

            output = mode_fc(amino_feature.to(device))


            feature_v1 = self.project(amino_feature_mean)
            feature_v2 = self.project(amino_feature_mean2)
            # data_dict['residual'] = output
            binary_label = data_dict['label_binary'] 
            for z in binary_label:
                final_label.append(z)
            batch_label_1= np.concatenate(final_label , 0)
            tet_cuda = torch.from_numpy(batch_label_1).to(device)
            # data_dict['batch_label'] = batch_label_1.to(device)

            # print(output.shape[0],batch_label_1.shape[0])
            # if output.shape[0] != batch_label_1.shape[0]:
                # a = 1 


        return output,tet_cuda,feature_v1,feature_v2




        