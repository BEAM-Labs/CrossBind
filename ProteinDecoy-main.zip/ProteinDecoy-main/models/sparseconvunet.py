import torch
import torch.nn as nn

import sparseconvnet as scn
from collections import Counter
import numpy as np
import torch.nn.functional as F  
import esm
def get_model(config):
    return SparseConvUnet(config)

def get_loss(config):
    return Loss(config)

class SparseConvUnet(nn.Module):
    def __init__(self, config):
        super().__init__()


        self.config = config
        m = config.m
        input_dim = 30 if config.use_coords else 27
        self.sparseModel = scn.Sequential().add(
           scn.InputLayer(3, config.full_scale, mode=config.mode)).add(
           scn.SubmanifoldConvolution(3, input_dim, m, 3, False)).add(
               scn.UNet(dimension=3,
                        reps=config.block_reps,
                        nPlanes=[m, 2*m, 3*m, 4*m, 5*m, 6*m, 7*m],
                        residual_blocks=config.block_residual,
                        )).add(
           scn.BatchNormReLU(m)).add(
           scn.OutputLayer(3))



        self.lstm = nn.LSTM(
            input_size=1088,# 
            hidden_size=128,# 
            batch_first=True,# 
        )

        if 'regression' in config:
            self.fc1 = nn.Linear(14*m, 64)
            self.fc1_esm = nn.Linear(640, 128)
            self.fc1_mix = nn.Linear(1088, 128)
            self.fc2 = nn.Linear(64,1)
            self.fc3 = nn.Linear(64,1)
            self.dropout = torch.nn.Dropout(p=0.5)

    def forward(self, data_dict,device,esm_out):
        am = data_dict['coords'][:,0:3]
        input_batch = [
            data_dict['coords'],
            data_dict['features']
        ]

        feature = self.sparseModel(input_batch)

        if 'classification' in self.config:
            clf = self.classifier(feature)
            output = torch.sigmoid(clf)
        
            data_dict['bin'] = output

            

        if 'regression' in self.config:
            
            atom_num = data_dict['atom_num']
            label_binary = data_dict['label_binary']
            index = 0
            # aa_feature = torch.zeros(len(label_binary[0]) ,14 ,feature.shape[1])

            # aa_feature_mean = torch.zeros(len(label_binary[0])  ,feature.shape[1])
            # print('model^^^^^^^^^^^^')
            idn = 0
            final_feature = []
            final_label = []
            feature = feature.cpu()

            
            for z in (atom_num):
                idn += 1
                aa_feature = torch.zeros(len(z) ,14 ,feature.shape[1])
                aa_feature_mean = torch.zeros(len(z)  ,feature.shape[1])            
                j = 0
                
                for i in z:
                    # aa_in = aa_index + j
                    # test = feature[index:(index+i),:]
                    aa_feature[j,:i,:] = feature[index:(index+i),:]
                    # mea = (torch.mean(feature[index:(index+i),:] , 0)).unsqueeze(0)
                    # aa_feature_mean[j,:] = mea
                    index = index + i 
                    j += 1

                final_feature.append(aa_feature)
                # final_feature.append(aa_feature_mean)
            feature_batch = torch.cat(final_feature , 0)
            aa_feature = torch.flatten(feature_batch,1,2)
            # out = self.fc1(aa_feature)
            # out = self.fc1(feature)

            ####concat esm pointsite:
            # esm_out = esm_out.squeeze(0)
            # mix_feature = torch.cat((aa_feature.to(device),esm_out),1)
            # # mix_feature = aa_feature
            # # out = F.elu(self.fc1_mix(mix_feature.to(device)))#.cuda())
            # out, h_n = self.lstm(mix_feature.to(device), None)
            # # out = F.elu(self.fc1(aa_feature.to(device))) 
            # # out = F.elu(self.fc1_esm(esm_out.to(device))) 
            # # out = self.dropout(out)
            # out = F.elu(self.fc2(out))  
            # # out = self.dropout(out)

            # output = torch.sigmoid(self.fc3(out))            

            ########
            out = F.elu(self.fc1(aa_feature.to(device)))#.cuda())
            out = self.fc2(out)
            output = torch.sigmoid(out)

            # data_dict['residual'] = output
            binary_label = data_dict['label_binary'] 
            for z in binary_label:
                final_label.append(z)
            batch_label_1= np.concatenate(final_label , 0)
            tet_cuda = torch.from_numpy(batch_label_1).to(device)
            # data_dict['batch_label'] = batch_label_1.to(device)

            # print(output.shape[0],batch_label_1.shape[0])
            # if output.shape[0] != batch_label_1.shape[0]:
                # a = 1 


        return output,tet_cuda


class base_model(torch.nn.Module):   # 继承 torch 的 Module
    def __init__(self):
        super().__init__()    # 

        # self.esm_model, self.esm_alphabet = esm.pretrained.esm2_t33_650M_UR50D()
        self.esm_model, self.esm_alphabet = esm.pretrained.esm2_t30_150M_UR50D()
        self.esm_model.eval()
        # self.batch_converter = self.esm_alphabet.get_batch_converter()

        self.fc1 = torch.nn.Linear(656,128)#.to('cuda:0')
        self.fc2 = torch.nn.Linear(128,64)#.to('cuda:0')

        self.fc3 = torch.nn.Linear(64,1)#.to('cuda:0')

        self.stru = torch.nn.Linear(16,1)#.to('cuda:0')
        self.dropout = torch.nn.Dropout(p=0.5)


    def get_alphabet(self):
        return self.esm_alphabet

        
    def forward(self,batch_tokens):

        with torch.no_grad():
            results = self.esm_model(batch_tokens, repr_layers=[30], return_contacts=True)
            token_representations = results["representations"][30]
        
        # structure_representations = torch.cat((token_representations, structure_seq),2)
        # structure_representations = torch.cat((structure_seq, token_representations),2)

        return token_representations

class Loss(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config

    def forward(self, data_dict,device):
        loss_fun = torch.nn.BCELoss()
        loss = 0
        
        if 'classification' in self.config and 'regression' in self.config:
            cls_pred = data_dict['bin']
            reg_pred = data_dict['residual']
            cls_labels = data_dict['cls_labels']
            reg_labels = data_dict['reg_labels']

            # bin-based classification
            cls_loss = self.config.classification.weight * \
                    torch.nn.functional.cross_entropy(cls_pred, cls_labels)
            loss += cls_loss
            data_dict['cls_loss'] = cls_loss

            # just regress residual
            reg_labels = reg_labels - (cls_pred.argmax(1).float() / self.config.classification.num_bins)
            reg_loss = self.config.regression.weight * \
                       torch.nn.functional.smooth_l1_loss(reg_pred, reg_labels)
            loss += reg_loss
            data_dict['reg_loss'] = reg_loss

        elif 'classification' in self.config and 'regression' not in self.config:
            cls_pred = data_dict['bin']
            # cls_labels = data_dict['cls_labels']
            cls_labels = data_dict['reg_labels']
            cls_labels = cls_labels.unsqueeze(1)

            label = []
            for i in data_dict['label_binary'][0]:
                label.append(float(i))
            label_binary = np.array(label)
            label_tensor = torch.from_numpy(label_binary).unsqueeze(1)

            a = np.where(cls_labels == 0)
            b = np.where(cls_labels != 0)
            c = np.where(cls_labels == 1.0)
            # print(c[0])
            # cls_loss = self.config.classification.weight * \
            #         loss_fun(cls_pred.float(),cls_labels.float())
                    # torch.nn.BCELoss(cls_pred, cls_labels)
            cls_loss =  loss_fun(cls_pred.float(),label_tensor.float())

            loss += cls_loss
            data_dict['cls_loss'] = cls_loss
            data_dict['label'] = cls_labels

        elif 'regression' in self.config and 'classification' not in self.config:
            reg_pred = data_dict['residual']
            reg_labels = data_dict['reg_labels']
            reg_labels = reg_labels.unsqueeze(1)

            # label = []
            # # for i in data_dict['label_binary'][0]:
            # for i in data_dict['batch_label']:

            #     label.append(float(i))
            # label_binary = np.array(label)
            # label_tensor = torch.from_numpy(label_binary).unsqueeze(1)
            label_tensor = data_dict['batch_label'].unsqueeze(1)
            # reg_loss = self.config.regression.weight * \
            #         torch.nn.functional.smooth_l1_loss(reg_pred.squeeze(), reg_labels, size_average=True, reduce=True)
            ######## Atom level regression
            # reg_loss =  loss_fun(reg_pred.float(),reg_labels.float())
            ######### AA Level 
            reg_loss =  loss_fun(reg_pred.float(),label_tensor.float().to(device))#.cuda())

            loss += reg_loss
            data_dict['reg_loss'] = reg_loss
            data_dict['label'] = reg_labels
            data_dict['binary_label'] = label_tensor
        else:
            raise TypeError('Please set at lease one from `classification` and `regression` in yaml fime!')

        data_dict['loss'] = loss

        return data_dict

