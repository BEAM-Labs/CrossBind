import torch
import torch.nn as nn

import sparseconvnet as scn
from collections import Counter
import numpy as np
import torch.nn.functional as F  
import esm
from torch.nn import init
from sklearn import preprocessing
def get_model(config):
    return SparseConvUnet(config)

def get_loss(config):
    return Loss(config)

fii = [-0.44985162,  0.73240308,  0.45873502, -0.26693213,  1.2191339 ,
0.31799025, -0.70646635,  0.06760465,  0.80724017, -0.41348552,
-1.09356942,  0.44781314,  0.91290933,  0.18138941,  0.15670218,
0.17694924,  0.30954355,  1.31420132,  0.60408098, -0.54580296,
1.3 ]

aa_list = ['A', 'R', 'N', 'D', 'C', 'Q', 'E', 'G', 'H', 'I', 'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W', 'Y', 'V', 'X']




class ScaledDotProductAttention(nn.Module):
    '''
    Scaled dot-product attention
    '''

    def __init__(self, d_model=32, d_k=14, d_v=14, h=4, dropout=.1):
        '''
        :param d_model: Output dimensionality of the model
        :param d_k: Dimensionality of queries and keys
        :param d_v: Dimensionality of values
        :param h: Number of heads
        '''
        super(ScaledDotProductAttention, self).__init__()
        self.fc_q = nn.Linear(d_model, h * d_k)
        self.fc_k = nn.Linear(d_model, h * d_k)
        self.fc_v = nn.Linear(d_model, h * d_v)
        self.fc_o = nn.Linear(h * d_v, d_model)
        self.dropout = nn.Dropout(dropout)

        self.d_model = d_model
        self.d_k = d_k
        self.d_v = d_v
        self.h = h

        self.fc1_mix_hhm = nn.Linear(4, 64) ##502, 950 , 448 , 1782

        # self.fc2 = nn.Linear(128,64)
        # self.fc3 = nn.Linear(64,1)

        self.init_weights()

    def init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                init.normal_(m.weight, std=0.001)
                if m.bias is not None:
                    init.constant_(m.bias, 0)

    def forward(self, data, attention_mask=None, attention_weights=None):
        '''
        Computes
        :param queries: Queries (b_s, nq, d_model)
        :param keys: Keys (b_s, nk, d_model)
        :param values: Values (b_s, nk, d_model)
        :param attention_mask: Mask over attention values (b_s, h, nq, nk). True indicates masking.
        :param attention_weights: Multiplicative weights for attention values (b_s, h, nq, nk).
        :return:
        '''
        # data = torch.flatten(data,0,1)
        # data = torch.from_numpy(data)
        data = data.unsqueeze(0)
        data = data.to(torch.float32)
        queries, keys, values = data,data,data
        b_s, nq = queries.shape[:2]
        nk = keys.shape[1]

        q = self.fc_q(queries).view(b_s, nq, self.h, self.d_k).permute(
            0, 2, 1, 3)  # (b_s, h, nq, d_k)
        k = self.fc_k(keys).view(b_s, nk, self.h, self.d_k).permute(
            0, 2, 3, 1)  # (b_s, h, d_k, nk)
        v = self.fc_v(values).view(b_s, nk, self.h, self.d_v).permute(
            0, 2, 1, 3)  # (b_s, h, nk, d_v)

        att = torch.matmul(q, k) / np.sqrt(self.d_k)  # (b_s, h, nq, nk)
        if attention_weights is not None:
            att = att * attention_weights
        if attention_mask is not None:
            att = att.masked_fill(attention_mask, -np.inf)
        att = torch.softmax(att, -1)
        att = self.dropout(att)

        out = torch.matmul(att, v).permute(0, 2, 1, 3).contiguous().view(
            b_s, nq, self.h * self.d_v)  # (b_s, nq, h*d_v)
        out = self.fc_o(out)  # (b_s, nq, d_model)


        # out = (self.fc1_mix_hhm(out))
        # out =self.fc1_mix_hhm(final_input)
        # #######

        # # out = F.elu(self.fc2(out))  
        # # output = torch.sigmoid(self.fc3(out))   

        # output = torch.sigmoid(out)     

        # output = output.squeeze(0)
        return out



class Mix_net(nn.Module):
    def __init__(self):
        super().__init__()


        self.lstm = nn.LSTM(
            input_size=4,# 
            hidden_size=12,# 
            batch_first=True,# 
        )

        self.fc1 = nn.Linear(54, 1)
        self.fc1_esm = nn.Linear(640, 128)
        self.fc1_mix = nn.Linear(1088, 128)
        self.fc1_fu = nn.Linear(14*32, 128)
        self.fc1_mix_hhm = nn.Linear(448, 128) ##502, 950 , 448 , 1782

        self.fc2 = nn.Linear(128,64)
        self.fc3 = nn.Linear(64,1)
        self.dropout = torch.nn.Dropout(p=0.5)
        self.w1 = nn.Parameter(torch.FloatTensor([0.5]), requires_grad=True)
    def forward(self, aa_features,esm_out,all_feature,animo_electric,data_dict,device):
        
        
            ####concat esm pointsite:
        # esm_out = esm_out.squeeze(0)
        # mix_feature = torch.cat((aa_features,esm_out),1)
        # # out, h_n = (self.lstm(mix_feature, None))
        # # out = F.elu(out)
        # # mix_feature = aa_feature
        # final_input = torch.concat((mix_feature,all_feature),1)
        # # out = F.elu(self.fc1_mix(final_input))#.cuda())
        # out = F.elu(self.fc1_mix_hhm(final_input))
        ###########
        ######### fusion
        w1 = torch.sigmoid(self.w1)
        esm_out = esm_out.squeeze(0)
        fusion = torch.add((1-w1)*esm_out , w1*aa_features)


        # scalera = preprocessing.MinMaxScaler(feature_range = (0.9,1.1))
        # fii_input = np.array(fii).reshape(-1,1)
        # new_fii = scalera.fit_transform(fii_input)
        # new_fii = torch.from_numpy(new_fii).to(device)
        # A_name = []
        # xx = data_dict['protein_seq']
        # for i in xx[0]:
        #     A_name.append((i))
        # AA_name = np.array(A_name)
        # fusion_new = fusion.clone()
        # import math
        # for i in range (fusion_new.shape[0]):
        #     a = aa_list.index(AA_name[i])
        #     # final_input_new[i] = final_input_new[i] * (1/(1 + np.exp(-fii[a])))
        #     # print(fusion_new[i].shape,new_fii[a].shape )
        #     fusion_new[i] = fusion_new[i] * new_fii[a]
    
        # fusion = esm_out
        # fusion = torch.add(esm_out , aa_features)
        # final_input  = fusion


# 
        # final_input = torch.concat((fusion,all_feature),1)
        final_input = fusion

        # animo_electric = animo_electric.squeeze(0)
        # aaaa,h_n = self.lstm(animo_electric, None)
        # final_result = torch.concat((final_input,aaaa),1)
        # scalera = preprocessing.MinMaxScaler(feature_range = (0.9,1.1))
        # fii_input = np.array(fii).reshape(-1,1)
        # new_fii = scalera.fit_transform(fii_input)
        # new_fii = torch.from_numpy(new_fii).to(device)
        # A_name = []
        # xx = data_dict['protein_seq']
        # for i in xx[0]:
        #     A_name.append((i))
        # AA_name = np.array(A_name)
        # final_input_new = final_input.clone()
        # import math
        # for i in range (final_input_new.shape[0]):
        #     a = aa_list.index(AA_name[i])
        #     # final_input_new[i] = final_input_new[i] * (1/(1 + np.exp(-fii[a])))
        #     print(final_input_new[i].shape,new_fii[a].shape )
        #     final_input_new[i] = final_input_new[i] * new_fii[a]
        # out = F.elu(self.fc1_fu(fusion))
        out = F.elu(self.fc1_mix_hhm(final_input))
        #######
        # out = F.elu(self.fc1_mix_hhm(final_input))
        # out = self.dropout(out)
        out = F.elu(self.fc2(out))  
        # out = self.dropout(out)

        output = torch.sigmoid(self.fc3(out))   
        # output = torch.sigmoid(self.fc1(final_input))           

        # return final_input
        return output

class base_model(torch.nn.Module):   # 继承 torch 的 Module
    def __init__(self):
        super().__init__()    # 

        self.esm_model, self.esm_alphabet = esm.pretrained.esm2_t33_650M_UR50D()
        # self.esm_model, self.esm_alphabet = esm.pretrained.esm2_t30_150M_UR50D()
        # self.esm_model, self.esm_alphabet = esm.pretrained.esm2_t6_8M_UR50D()
        # self.esm_model.eval()
        # self.batch_converter = self.esm_alphabet.get_batch_converter()
        # self.fc1 = torch.nn.Linear(640,448)#.to('cuda:0')
        self.fc1 = torch.nn.Linear(1280,448)#.to('cuda:0')
        # self.fc1 = torch.nn.Linear(320,448)#.to('cuda:0')
        self.dropout = torch.nn.Dropout(p=0.5)


    def get_alphabet(self):
        return self.esm_alphabet

        
    def forward(self,batch_tokens):

        # with torch.no_grad():
        results = self.esm_model(batch_tokens, repr_layers=[33], return_contacts=True)
        token_representations = results["representations"][33]
        out = token_representations
        out = self.fc1(token_representations)
        
        # structure_representations = torch.cat((token_representations, structure_seq),2)
        # structure_representations = torch.cat((structure_seq, token_representations),2)

        return out
class Loss(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config

    def forward(self, data_dict,device):
        loss_fun = torch.nn.BCELoss()
        loss = 0



        
        if 'classification' in self.config and 'regression' in self.config:
            cls_pred = data_dict['bin']
            reg_pred = data_dict['residual']
            cls_labels = data_dict['cls_labels']
            reg_labels = data_dict['reg_labels']

            # bin-based classification
            cls_loss = self.config.classification.weight * \
                    torch.nn.functional.cross_entropy(cls_pred, cls_labels)
            loss += cls_loss
            data_dict['cls_loss'] = cls_loss

            # just regress residual
            reg_labels = reg_labels - (cls_pred.argmax(1).float() / self.config.classification.num_bins)
            reg_loss = self.config.regression.weight * \
                       torch.nn.functional.smooth_l1_loss(reg_pred, reg_labels)
            loss += reg_loss
            data_dict['reg_loss'] = reg_loss

        elif 'classification' in self.config and 'regression' not in self.config:
            cls_pred = data_dict['bin']
            # cls_labels = data_dict['cls_labels']
            cls_labels = data_dict['reg_labels']
            cls_labels = cls_labels.unsqueeze(1)

            label = []
            for i in data_dict['label_binary'][0]:
                label.append(float(i))
            label_binary = np.array(label)
            label_tensor = torch.from_numpy(label_binary).unsqueeze(1)

            a = np.where(cls_labels == 0)
            b = np.where(cls_labels != 0)
            c = np.where(cls_labels == 1.0)
            # print(c[0])
            # cls_loss = self.config.classification.weight * \
            #         loss_fun(cls_pred.float(),cls_labels.float())
                    # torch.nn.BCELoss(cls_pred, cls_labels)
            cls_loss =  loss_fun(cls_pred.float(),label_tensor.float())

            loss += cls_loss
            data_dict['cls_loss'] = cls_loss
            data_dict['label'] = cls_labels

        elif 'regression' in self.config and 'classification' not in self.config:

         
            aa_list = ['A', 'R', 'N', 'D', 'C', 'Q', 'E', 'G', 'H', 'I', 'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W', 'Y', 'V', 'X']


            reg_pred = data_dict['residual']
            reg_labels = data_dict['reg_labels']
            reg_labels = reg_labels.unsqueeze(1)

            # label = []
            # # for i in data_dict['label_binary'][0]:
            # for i in data_dict['batch_label']:

            #     label.append(float(i))
            # label_binary = np.array(label)
            # label_tensor = torch.from_numpy(label_binary).unsqueeze(1)
            label_tensor = data_dict['batch_label'].unsqueeze(1)
            # reg_loss = self.config.regression.weight * \
            #         torch.nn.functional.smooth_l1_loss(reg_pred.squeeze(), reg_labels, size_average=True, reduce=True)
            ######## Atom level regression
            # reg_loss =  loss_fun(reg_pred.float(),reg_labels.float())

            # for i in xx[0]:
            #     A_name.append((i))
            # AA_name = np.array(A_name)
            # reg_pred_new = reg_pred.clone()
            # import math
            # for i in range (reg_pred.shape[0]):
            #     a = aa_list.index(AA_name[i])
            #     # reg_pred_new[i] = reg_pred_new[i] * (1/(1 + np.exp(-fii[a])))
            #     reg_pred_new[i] = reg_pred_new[i] * new_fii[a]
            #     idxs = torch.where(reg_pred_new>1) 
            #     idxs2 = torch.where(reg_pred_new<0) 
            #     reg_pred_new[idxs] = 1
            #     reg_pred_new[idxs2] = 0


            ######### AA Level 
            # reg_loss =  loss_fun(reg_pred_new.float(),label_tensor.float().to(device))#.cuda())
            reg_loss =  loss_fun(reg_pred.float(),label_tensor.float().to(device))#.cuda())

            loss = reg_loss
            data_dict['reg_loss'] = reg_loss
            data_dict['label'] = reg_labels
            data_dict['binary_label'] = label_tensor

        data_dict['loss'] = loss

        return data_dict

class atom_attention(nn.Module):
    def __init__(self):
        super().__init__()


        self.attention = nn.Linear(448 , 14,bias=False)
        # self.attention2 = nn.Linear(6,14,bias=False)
        self.embedding = nn.Linear(448, 448)

    def forward(self,x):
        fee = torch.flatten(x,0,1)
        # fee = torch.mean(x,1)
        atom_atten = self.attention(fee)
        # atom_atten = F.relu(atom_atten)
        # aaa = self.attention2(atom_atten)
        atten_par =  torch.sigmoid(atom_atten)

        after_attention = atten_par.unsqueeze(1) * x 
        fee2 = torch.flatten(after_attention,0,1)
        output = self.embedding(fee2)
        output = output.reshape(14,32)
        # return output.unsqueeze(1)
        return output


class SparseConvUnet(nn.Module):
    def __init__(self, config):
        super().__init__()


        self.config = config
        m = config.m
        input_dim = 30 if config.use_coords else 27
        self.sparseModel = scn.Sequential().add(
           scn.InputLayer(3, config.full_scale, mode=config.mode)).add(
           scn.SubmanifoldConvolution(3, input_dim, m, 3, False)).add(
               scn.UNet(dimension=3,
                        reps=config.block_reps,
                        nPlanes=[m, 2*m, 3*m, 4*m, 5*m, 6*m, 7*m],
                        residual_blocks=config.block_residual,
                        )).add(
           scn.BatchNormReLU(m)).add(
           scn.OutputLayer(3))



        self.lstm = nn.LSTM(
            input_size=1088,# 传入我们上面定义的参数
            hidden_size=1280,# 传入我们上面定义的参数
            batch_first=True,# 为什么设置为True上面解释过了
        )

        if 'regression' in config:
            self.fc1 = nn.Linear(14*m, 1)
            # self.fc1 = nn.Linear(1*m, 1)
            self.fc2 = nn.Linear(128,64)
            self.fc3 = nn.Linear(64,1)
            self.dropout = torch.nn.Dropout(p=0.5)

            # self.attention = nn.Linear(14*m , 14)
            # self.embedding = nn.Linear(14*m,14*m)

            self.project = nn.Sequential(
                nn.Linear(32, 32, bias = False),
                nn.BatchNorm1d(32),
                nn.ReLU(inplace=True),
                nn.Linear(32, 32, bias = False)
                ) 

    def forward(self, data_dict,device,attention_model):

        # with torch.no_grad():
        am = data_dict['coords'][:,0:3]
        input_batch = [
            data_dict['coords'],
            data_dict['features']
        ]

        feature = self.sparseModel(input_batch)

            

        if 'regression' in self.config:
            
            atom_num = data_dict['atom_num']
            label_binary = data_dict['label_binary']
            index = 0
            # aa_feature = torch.zeros(len(label_binary[0]) ,14 ,feature.shape[1])

            # aa_feature_mean = torch.zeros(len(label_binary[0])  ,feature.shape[1])
            # print('model^^^^^^^^^^^^')
            idn = 0
            final_feature = []
            final_feature_attention = []
            final_label = []

        
            for z in (atom_num):
                idn += 1
                aa_feature = torch.zeros(len(z) ,14 ,feature.shape[1])
                aa_feature_attention = torch.zeros(len(z) ,14 ,feature.shape[1])
                aa_feature_mean = torch.zeros(len(z)  ,feature.shape[1])            
                j = 0
                
                for i in z:
                    # aa_in = aa_index + j
                    # test = feature[index:(index+i),:]
                    aa_feature[j,:i,:] = feature[index:(index+i),:]

                    atom_wise = aa_feature[j,:].clone()
                    # mea = (torch.mean(feature[index:(index+i),:] , 0)).unsqueeze(0)
                    # aa_feature_mean[j,:] = mea
                    index = index + i 
                    # atom_w = attention_model(atom_wise.to(device))
                    # atom_w = atom_w.squeeze(0)
                    
                    # aa_feature_attention[j,:] = atom_w
                    aa_feature_attention = aa_feature
                    j += 1

                final_feature_attention.append(aa_feature_attention)
                final_feature.append(aa_feature)
                # final_feature.append(aa_feature_mean)
            feature_batch = torch.cat(final_feature , 0)
            aa_feature = torch.flatten(feature_batch,1,2)

            feature_batch_attention = torch.cat(final_feature_attention , 0)
            aa_feature_attention = torch.flatten(feature_batch_attention,1,2)


            # out = self.fc1(aa_feature.to(device))#.cuda())
            # output = torch.sigmoid(out)


            # data_dict['residual'] = output
            binary_label = data_dict['label_binary'] 
            for z in binary_label:
                final_label.append(z)
            batch_label_1= np.concatenate(final_label , 0)
            tet_cuda = torch.from_numpy(batch_label_1).to(device)
            # data_dict['batch_label'] = batch_label_1.to(device)

            # print(output.shape[0],batch_label_1.shape[0])
            # if output.shape[0] != batch_label_1.shape[0]:
                # a = 1 


        # return aa_feature,tet_cuda
        return aa_feature_attention,tet_cuda




# class SparseConvUnet(nn.Module):
#     def __init__(self, config):
#         super().__init__()


#         self.config = config
#         m = config.m
#         input_dim = 30 if config.use_coords else 27
#         self.sparseModel = scn.Sequential().add(
#            scn.InputLayer(3, config.full_scale, mode=config.mode)).add(
#            scn.SubmanifoldConvolution(3, input_dim, m, 3, False)).add(
#                scn.UNet(dimension=3,
#                         reps=config.block_reps,
#                         nPlanes=[m, 2*m, 3*m, 4*m, 5*m, 6*m, 7*m],
#                         residual_blocks=config.block_residual,
#                         )).add(
#            scn.BatchNormReLU(m)).add(
#            scn.OutputLayer(3))



#         self.lstm = nn.LSTM(
#             input_size=1088,# 传入我们上面定义的参数
#             hidden_size=1280,# 传入我们上面定义的参数
#             batch_first=True,# 为什么设置为True上面解释过了
#         )

#         if 'regression' in config:
#             # self.fc1 = nn.Linear(14*m, 1)
#             self.fc1 = nn.Linear(14*m, 1)
#             self.fc2 = nn.Linear(128,64)
#             self.fc3 = nn.Linear(64,1)
#             self.dropout = torch.nn.Dropout(p=0.5)

#             self.attention = nn.Linear(448 , 14,bias=False)
#         # self.attention2 = nn.Linear(6,14,bias=False)
#             self.embedding = nn.Linear(448, 448)

#     def forward(self, data_dict,device,attention_model):
#         am = data_dict['coords'][:,0:3]
#         input_batch = [
#             data_dict['coords'],
#             data_dict['features']
#         ]

#         feature = self.sparseModel(input_batch)

            

#         if 'regression' in self.config:
            
#             atom_num = data_dict['atom_num']
#             label_binary = data_dict['label_binary']
#             index = 0
#             # aa_feature = torch.zeros(len(label_binary[0]) ,14 ,feature.shape[1])

#             # aa_feature_mean = torch.zeros(len(label_binary[0])  ,feature.shape[1])
#             # print('model^^^^^^^^^^^^')
#             idn = 0
#             final_feature = []
#             final_label = []
#             final_feature_attention = []            
            
#             for z in (atom_num):
#                 idn += 1
#                 aa_feature = torch.zeros(len(z) ,14 ,feature.shape[1])
#                 aa_feature_attention = torch.zeros(len(z) ,14 ,feature.shape[1])
#                 # aa_feature_mean = torch.zeros(len(z)  ,feature.shape[1])            
#                 j = 0
                
#                 for i in z:
#                     # aa_in = aa_index + j
#                     # test = feature[index:(index+i),:]
#                     aa_feature[j,:i,:] = feature[index:(index+i),:]

#                     # mea = (torch.mean(feature[index:(index+i),:] , 0)).unsqueeze(0)
#                     # aa_feature_mean[j,:] = mea
#                     atom_wise = aa_feature[j,:].clone()
#                     attention_input = torch.flatten(atom_wise,0,1)
#                     attention_out = self.attention(attention_input.to(device))
#                     atom_par = torch.sigmoid(attention_out)
#                     after_attention = atom_par.unsqueeze(1) * atom_wise.to(device) 
#                     fee2 = torch.flatten(after_attention,0,1)
#                     att_out = self.embedding(fee2)
#                     att_out = att_out.reshape(14,32)

#                     aa_feature_attention[j,:] = att_out
#                     index = index + i 
#                     j += 1

#                 final_feature_attention.append(aa_feature_attention)
#                 final_feature.append(aa_feature)
#                 # final_feature.append(aa_feature_mean)
#             feature_batch = torch.cat(final_feature , 0)
#             aa_feature = torch.flatten(feature_batch,1,2)

#             feature_batch_attention = torch.cat(final_feature_attention , 0)
#             aa_feature_attention = torch.flatten(feature_batch_attention,1,2)


#             # data_dict['residual'] = output
#             binary_label = data_dict['label_binary'] 
#             for z in binary_label:
#                 final_label.append(z)
#             batch_label_1= np.concatenate(final_label , 0)
#             tet_cuda = torch.from_numpy(batch_label_1).to(device)
#             # data_dict['batch_label'] = batch_label_1.to(device)

#             # print(output.shape[0],batch_label_1.shape[0])
#             # if output.shape[0] != batch_label_1.shape[0]:
#                 # a = 1 


#         return aa_feature_attention,tet_cuda
