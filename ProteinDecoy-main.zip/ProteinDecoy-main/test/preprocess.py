import pickle
import os
import argparse
import numpy as np
from tqdm import tqdm
from joblib import Parallel, delayed

parser = argparse.ArgumentParser(description='Argument Parser')
parser.add_argument('--pdbpath', default='./examples/pdb/', help='Path of pdb files')
parser.add_argument('--xyzpath', default='./examples/xyz/', help='Path of xyz files to save')
parser.add_argument('--pklpath', default='./examples/pkls/', help='Path of pkl files to save')
parser.add_argument('--LIG_path', default='./LIG_Tool/util/PDB_To_XYZ', help='Path of PDB_To_XYZ file')
parser.add_argument('--workers', default=4, help='Number of threads')
args = parser.parse_args()

pdbpath = args.pdbpath
xyzpath = args.xyzpath
pklpath = args.pklpath
LIG_path = args.LIG_path
workers = args.workers

if not os.path.exists(xyzpath):
    os.makedirs(xyzpath)
if not os.path.exists(pklpath):
    os.makedirs(pklpath)

aa_list = ['A', 'R', 'N', 'D', 'C', 'Q', 'E', 'G', 'H', 'I', 'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W', 'Y', 'V', 'X']
atom_list = ['N', 'C', 'O', 'S', 'H', 'X']

def pdb2xyz(pdb_file):
    print('pdb2xyz: ' + pdb_file)
    pdb_dir = pdbpath + pdb_file
    xyz_dir = xyzpath + pdb_file.replace('.pdb', '.xyz')
    os.system(LIG_path + ' -i %s -a 1 -o %s' % (pdb_dir, xyz_dir))

def xyz2pkl(xyz_file):
    print('xyz2pkl: ' + xyz_file)
    xyz_dir = xyzpath + xyz_file
    pkl_dir = pklpath + xyz_file.replace('.xyz', '.pkl')
    data = np.loadtxt(xyz_dir, dtype=str)
    xyz = data[:, 2:5].astype(float)
    aa_feature = np.zeros((xyz.shape[0]), dtype=np.int8)
    atom_feature = np.zeros((xyz.shape[0]), dtype=np.int8)
    residue_head = data[:, 0]
    residue_idx = np.zeros(xyz.shape[0])
    for i, feat in enumerate(data[:, 1]):
        aa_feature[i] = aa_list.index(feat[0])
        atom_feature[i] = atom_list.index(feat[1])
        res_idx = int(residue_head[i][residue_head[i].find('|') + 1:])
        residue_idx[i] = res_idx
    with open(pkl_dir, 'wb') as file:
        pickle.dump(xyz, file)  # dump xyz data
        pickle.dump(aa_feature, file)  # dump amino acid feature
        pickle.dump(atom_feature, file)  # dump atom feature
        pickle.dump(residue_idx, file)  # dump residue index



all_pdbs = os.listdir(pdbpath)
Parallel(n_jobs=workers)(delayed(pdb2xyz)(pdb_file) for pdb_file in all_pdbs)

all_xyzs = os.listdir(xyzpath)
Parallel(n_jobs=workers)(delayed(xyz2pkl)(xyz_file) for xyz_file in all_xyzs)




