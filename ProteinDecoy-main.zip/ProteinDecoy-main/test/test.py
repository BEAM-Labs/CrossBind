import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(BASE_DIR)
sys.path.append(os.path.join(BASE_DIR))

import math
import glob
import torch
import argparse
import random
import importlib
import pickle

import numpy as np
import time

from utils.logger import setup_logger
from checkpoint.config import cfg, cfg_from_yaml_file

aa_list = ['A', 'R', 'N', 'D', 'C', 'Q', 'E', 'G', 'H', 'I', 'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W', 'Y', 'V', 'X']
atom_list = ['N', 'C', 'O', 'S', 'H', 'X']

def load_checkpoint(args, model):
    checkpoint = torch.load(args.ckpt_path, map_location='cpu')
    model.load_state_dict(checkpoint['model'])
    logger.info("=> loaded successfully '{}'".format(args.ckpt_path))
    del checkpoint
    torch.cuda.empty_cache()

def load_data(file):
    with open(file,'rb') as f:
        xyz = pickle.load(f)  # load xyz data
        aa_feature = pickle.load(f)  # load amino acid feature
        atom_feature = pickle.load(f)  # load atom feature
        residue_idx = pickle.load(f)  # load residue index

    return {
        'xyz': xyz,
        'aa_feature': aa_feature,
        'atom_feature': atom_feature,
        'residue_idx': residue_idx,
        'name': file
    }


def process_input_data(data_dict, config, vote_num=3):
    xyz = data_dict['xyz']
    aa_feature = data_dict['aa_feature']
    atom_feature = data_dict['atom_feature']
    aa_one_hot = np.zeros((len(aa_feature), 21))
    atom_one_hot = np.zeros((len(atom_feature), 6))
    for i, feat in enumerate(aa_feature):
        aa_one_hot[i, aa_feature[i]] = 1
        atom_one_hot[i, atom_feature[i]] = 1
    feature = np.concatenate([aa_one_hot, atom_one_hot], 1)

    coords = []
    features = []

    # divide by voxel size
    for v in range(vote_num):
        coord = np.ascontiguousarray(xyz - xyz.mean(0))
        m = np.eye(3) + np.random.randn(3, 3) * 0.1
        m[0][0] *= np.random.randint(0, 2) * 2 - 1
        m /= config.voxel_size

        # rotation (currently only on z-axix)
        theta = np.random.rand() * 2 * math.pi
        m = np.matmul(m, [[math.cos(theta), math.sin(theta), 0], [-math.sin(theta), math.cos(theta), 0], [0, 0, 1]])
        coord = np.matmul(coord, m)

        # place on (0,0) and crop out the voxel outside the full_scale
        m = coord.min(0)
        M = coord.max(0)
        offset = - m + np.clip(config.full_scale - M + m - 0.001, 0, None) * np.random.rand(3) + \
                 np.clip(config.full_scale - M + m + 0.001, None, 0) * np.random.rand(3)

        coord += offset
        coord = torch.Tensor(coord).long()
        coords.append(torch.cat([coord, torch.LongTensor(coord.shape[0], 1).fill_(v)], 1))
        features.append(torch.Tensor(feature))

    inputs = {
        'coords': torch.cat(coords, 0),
        'features': torch.cat(features, 0)
    }

    return inputs

def atom_to_residue(atom_lddt,res_index):
    s_len=int(res_index[-1])
    res_index=np.array(res_index)
    res_index=res_index-1
    new_pool=[[] for ii in range(s_len)]
    reduce_array=np.zeros((s_len))
    for rid in range(len(res_index)):
        new_pool[int(res_index[rid])].append(atom_lddt[rid])
    for rid2 in range(s_len):
        tmp_arr=np.array(new_pool[rid2])
        new_arr=np.mean(tmp_arr)
        reduce_array[rid2]=new_arr
    return reduce_array

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu', type=str, default='0', help='Specify gpu devices')
    parser.add_argument('--data_path', type=str, default='./examples/pkls/', help='Data folder containing pkl files')
    parser.add_argument('--xyz_path', type=str, default='./examples/xyz/', help='Data folder containing xyz files')
    parser.add_argument('--ckpt_path', type=str, default='./checkpoint/ckpt_decoy8k.pth', help='Path of checkpoint')
    parser.add_argument('--cfg_path', type=str, default='./checkpoint/SparseConv_AtomR.yaml', help='Path of config')
    parser.add_argument('--log_dir', type=str, default='./examples/prediction/', help='Prediction folder')
    parser.add_argument('--filename_suffix', type=str, default='atom_lddt', help='Filename suffix to save')
    parser.add_argument('--vote_num', type=int, default=3, help='Voting number')
    parser.add_argument('--save_atomlddt', action='store_true', default=True,
                        help='save atom-level in a txt file separately')

    args = parser.parse_args()
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    os.makedirs(args.log_dir, exist_ok=True)
    atom_dir = os.path.join(args.log_dir.strip(), "atom_lddt")
    res_dir = os.path.join(args.log_dir.strip(), "all_lddt")
    os.makedirs(atom_dir, exist_ok=True)
    os.makedirs(res_dir, exist_ok=True)

    torch.backends.cudnn.enabled = True
    torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.deterministic = True

    logger = setup_logger(output=args.log_dir + '/log_test.txt', name='testing')

    # load configuration
    cfg_file = args.cfg_path
    cfg_from_yaml_file(cfg_file, cfg)
    logger.info(cfg)

    # set random seed
    random.seed(cfg.manualSeed)
    torch.manual_seed(cfg.manualSeed)
    np.random.seed(cfg.manualSeed)
    torch.cuda.manual_seed(cfg.manualSeed)

    # model
    logger.info('Load Model...')
    f_model = importlib.import_module('checkpoint.' + 'sparseconvunet')
    model = f_model.get_model(cfg).cuda()
    load_checkpoint(args, model)

    # load data
    files=[]
    test_file_names=os.listdir(args.data_path)
    for item in test_file_names:
        files.append(args.data_path+item)
    num_files = len(files)

    model.eval()
    for f in files:
        times=time.time()
        file_name = f[f.rfind('/') + 1:]
        protein_name = file_name[:file_name.find('_')]
        chain_name = file_name
        data_dict = load_data(f)
        residue_idx = data_dict['residue_idx']

        vote_pool_regress = torch.zeros(data_dict['xyz'].shape[0], 1)
        point_idx = torch.arange(data_dict['xyz'].shape[0])
        point_idx = point_idx.repeat(args.vote_num)

        data = process_input_data(data_dict, cfg, vote_num=args.vote_num)
        torch.cuda.synchronize()

        for k in data.keys():
            if k in ['features', 'reg_labels']:
                data[k] = data[k].cuda()

        # get output
        end_points = model(data)

        if 'regression' in cfg:
            vote_pool_regress = vote_pool_regress.index_add_(0, point_idx, end_points['residual'].cpu())
            vote_pool_regress /= args.vote_num
            vote_pool_regress = vote_pool_regress.squeeze()
            prediction = vote_pool_regress
        else:
            raise TypeError('Please only set `regression` in yaml fime!')


        pred_list=prediction.detach().numpy()
        global_lddt=np.mean(pred_list)
        residue_lddt=atom_to_residue(pred_list,residue_idx)
        pred_dict={}
        pred_dict['atom_lddt']=pred_list
        pred_dict['residue_lddt']=residue_lddt
        pred_dict['global_lddt']=global_lddt
        np.save(os.path.join(res_dir, file_name[:-4]+'.npy'), pred_dict)

        if args.save_atomlddt:
            xyz_file=args.xyz_path+file_name[:-4]+'.xyz'
            save_data = np.loadtxt(xyz_file, dtype=str)
            save_data[:, -1] = pred_list
            np.savetxt(os.path.join(atom_dir, file_name[:-4]+'.atom_lddt'),
                   save_data, fmt='%s')

        timee = time.time()
        logger.info('Decoy: %s, Global lddt: %.4f, Time: %.4f' % (
            file_name[:-4], global_lddt, timee-times))









