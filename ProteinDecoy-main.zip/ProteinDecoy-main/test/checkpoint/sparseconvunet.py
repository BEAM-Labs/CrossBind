import torch
import torch.nn as nn

import sparseconvnet as scn


def get_model(config):
    return SparseConvUnet(config)

def get_loss(config):
    return Loss(config)

class SparseConvUnet(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        m = config.m
        input_dim = 30 if config.use_coords else 27
        self.sparseModel = scn.Sequential().add(
           scn.InputLayer(3, config.full_scale, mode=config.mode)).add(
           scn.SubmanifoldConvolution(3, input_dim, m, 3, False)).add(
               scn.UNet(dimension=3,
                        reps=config.block_reps,
                        nPlanes=[m, 2*m, 3*m, 4*m, 5*m, 6*m, 7*m],
                        residual_blocks=config.block_residual,
                        )).add(
           scn.BatchNormReLU(m)).add(
           scn.OutputLayer(3))

        if 'classification' in config:
            self.classifier = nn.Linear(m, config.classification.num_bins)

        if 'regression' in config:
            self.regressor = nn.Linear(m, 1)

    def forward(self, data_dict):
        input_batch = [
            data_dict['coords'],
            data_dict['features']
        ]

        feature = self.sparseModel(input_batch)

        if 'classification' in self.config:
            clf = self.classifier(feature)
            data_dict['bin'] = clf

        if 'regression' in self.config:
            reg = self.regressor(feature)
            data_dict['residual'] = reg

        return data_dict


class Loss(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config

    def forward(self, data_dict):
        loss = 0
        if 'classification' in self.config and 'regression' in self.config:
            cls_pred = data_dict['bin']
            reg_pred = data_dict['residual']
            cls_labels = data_dict['cls_labels']
            reg_labels = data_dict['reg_labels']

            # bin-based classification
            cls_loss = self.config.classification.weight * \
                    torch.nn.functional.cross_entropy(cls_pred, cls_labels)
            loss += cls_loss
            data_dict['cls_loss'] = cls_loss

            # just regress residual
            reg_labels = reg_labels - (cls_pred.argmax(1).float() / self.config.classification.num_bins)
            reg_loss = self.config.regression.weight * \
                       torch.nn.functional.smooth_l1_loss(reg_pred, reg_labels)
            loss += reg_loss
            data_dict['reg_loss'] = reg_loss

        elif 'classification' in self.config and 'regression' not in self.config:
            cls_pred = data_dict['bin']
            cls_labels = data_dict['cls_labels']
            cls_loss = self.config.classification.weight * \
                    torch.nn.functional.cross_entropy(cls_pred, cls_labels)
            loss += cls_loss
            data_dict['cls_loss'] = cls_loss

        elif 'regression' in self.config and 'classification' not in self.config:
            reg_pred = data_dict['residual']
            reg_labels = data_dict['reg_labels']

            reg_loss = self.config.regression.weight * \
                    torch.nn.functional.smooth_l1_loss(reg_pred.squeeze(), reg_labels, size_average=True, reduce=True)
            loss += reg_loss
            data_dict['reg_loss'] = reg_loss

        else:
            raise TypeError('Please set at lease one from `classification` and `regression` in yaml fime!')

        data_dict['loss'] = loss

        return data_dict