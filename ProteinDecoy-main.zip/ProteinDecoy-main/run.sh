#!/bin/bash

#SBATCH --quotatype=reserved
#SBATCH --job-name=DLPRB-CNN
#SBATCH --gres=gpu:1
# SBATCH --partition=ai4science
#SBATCH --partition=AI4Molecule


# ./train1.sh
# python -u GraphSite_predict.py
python -u /mnt/petrelfs/jinglinglin/Linglin/SpConv/ProteinDecoy-main/train.py