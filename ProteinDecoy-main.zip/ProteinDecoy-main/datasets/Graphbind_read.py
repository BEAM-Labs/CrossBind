
import torch
import torch.nn.functional as F   
from torchvision import datasets
import torchvision.transforms as transforms
import numpy as np
import torch.utils.data as Data
import torch
import pandas as pd
from torch.utils.data.dataset import Dataset

import os 
import numpy as np
from collections import Counter


def read_xyz(filename,data_id):
    locs = []
    d = {}
    ii = 0
    with open(filename, 'r') as f:
        l = f.readlines()  
        cc = len(l)
        # l = f.readlines().strip().split(" ")
    for i in range(cc):
        # if data_id[0] == ('2ok0_L' or '4gfh_A' or '2ayb_A' or '4z8f_H' ):
        # l[i].replace(' ','')
        a = l[i].strip().split(" ")
        c = a[2]
        if c == '':
            c = a[1]

        if c[-1] == '!':
            continue

        b = a[0]
        if_word = b[-1].isdigit()

        if if_word:
            locs.append(b)

    result = dict(Counter(locs))
    return result

def structure_data ():
    Dna_dict = {}
    files = os.listdir( '/nvme/xusheng1/Linglin/esm-main/data/DNA_RNA/DNA_feature/')
    for i in files:

        path = os.path.join('/nvme/xusheng1/Linglin/esm-main/data/DNA_RNA/DNA_feature/'+i)
        # i = i[:len(i)-4]
        i = i.strip('.npy')
        data = np.load(path)
        temp = {i : data}
        Dna_dict.update(**temp)

    return(Dna_dict)

def openreadtxt(file_name):
    data_id = []
    data_seq = []
    data_label = []
    structure_emb = {}
    
    file = open(file_name,'r')  #打开文件
    file_data = file.readlines() #读取所有行

    for row in file_data:
        if row[0] == '>':
            # data_id.append(row[1:len(row)-1])
            data_id.append(row[1:].strip('\n'))
            # id_s = row[1:].strip('\n')
            # structure_ = read_xyz(os.path.join('/mnt/petrelfs/jinglinglin/Linglin/SpConv/ProteinDecoy-main/datasets/cath_decoys/xyz_label/'+row[1:].strip('\n')+'.xyz' ),id_s)
            # temp = {row[1:].strip('\n') : structure_}
            # structure_emb.update(**temp)

        elif (row[0].isdigit()):
            row = row.strip('\n')
            data_label.append(row)
        else:
            row = row.strip('\n')
            data_seq.append(row)

           
    return data_id,data_seq,data_label

class ProtDatasetFromCSV(Dataset):
    def __init__(self, txt_path):

        data_id_dna,data_seq_dna,data_label_dna = openreadtxt(txt_path)
        self.data_dcit = structure_data()

        data=pd.DataFrame()
        data["ID"] = data_id_dna
        data["Seq"] = data_label_dna
        data["Label"] = data_seq_dna
        self.data = data
        self.structure_emb = structure_emb

    def __getitem__(self, index):
        rna_seq = self.data.iloc[index]['Seq']
        prot_id = self.data.iloc[index]['ID']
        label = self.data.iloc[index]['Label']
        structure_seq = self.data_dcit[prot_id]
        embedding = self.structure_emb[prot_id]
        # structure_seq = self.data_dcit['1d2i_A']
        # embedding = self.structure_emb['1d2i_A']

        result = []
        index = 0
        for i in  embedding.values():
            aaaa = structure_seq[index:(index+i),:]
            # aaa = np.mean(aaaa,0) 
            result.append(np.mean(structure_seq[index:(index+i),:],0))
            index = i
        result = torch.tensor(np.array(result))

        return rna_seq,label,prot_id,result


    def __len__(self):
        return len(self.data.index)


def ProtDatasetFromCSV(txt_path):
    data_id_dna,data_seq_dna,data_label_dna = openreadtxt(txt_path)
    data=pd.DataFrame()
    data["ID"] = data_id_dna
    data["Seq"] = data_label_dna
    data["Label"] = data_seq_dna
    return data

train_set = ProtDatasetFromCSV('/mnt/petrelfs/jinglinglin/Linglin/SpConv/ProteinDecoy-main/datasets/cath_decoys/DNA/DNA_Train_573.fa')