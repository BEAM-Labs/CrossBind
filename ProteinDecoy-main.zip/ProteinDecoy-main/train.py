# -*- coding: utf-8 -*-
'''
@Author: Linglin Jing
@File: train.py
@Time: 2021/6/29 16:11
'''

import os
import sys
sys.path.append(os.path.abspath('./ProteinDecoy-main'))
# sys.path.append(os.path.abspath('/mnt/petrelfs/jinglinglin/Linglin/SpConv/ProteinDecoy-main/cfgs'))

# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# sys.path.append(BASE_DIR)
# sys.path.append(os.path.join(BASE_DIR))

import pprint
import random
import argparse
import warnings
import importlib

import numpy as np
import torch.utils.data
import torch.optim as optim

from tqdm import tqdm
from datetime import datetime

from utils.lr_scheduler import get_scheduler
from utils.logger import setup_logger
from cfgs.config import cfg, cfg_from_yaml_file, backup_files
from utils.metrics import evaluators
from collections import Counter
# from models.sparseconvunet import base_model, SparseConvUnet_og
warnings.filterwarnings('ignore')
pp = pprint.PrettyPrinter()


def parse_config():
    parser = argparse.ArgumentParser()
    parser.add_argument('--cfg_file', type=str, default='./ProteinDecoy-main/cfgs/SparseConv-Cath-Decoys-Clf-Only.yaml', help='specify the config for training')
    parser.add_argument('--log_dir', type=str, default=None, help='specify the save direction for training')
    parser.add_argument('--batch_size', type=int, default=8, help='input batch size')
    parser.add_argument('--num_workers', type=int, default=None, help='number of data loading workers')
    parser.add_argument('--gpu', type=int, nargs='+', default=(0,), help='specify gpu devices')
    parser.add_argument('--debug', action='store_true', default=False, help='whether not to down sample PC')

    args = parser.parse_args()
    cfg_from_yaml_file(args.cfg_file, cfg)

    cfg.cfg_file = args.cfg_file
    cfg.debug = args.debug
    cfg.gpu = args.gpu
    cfg.log_dir = args.log_dir

    if args.batch_size is not None:
        cfg.batch_size = args.batch_size
    if args.num_workers is not None:
        cfg.num_workers = args.num_workers

    random.seed(cfg.manualSeed)
    torch.manual_seed(cfg.manualSeed)
    np.random.seed(cfg.manualSeed)
    torch.cuda.manual_seed(cfg.manualSeed)

    if cfg.log_dir:
        cfg.log_dir = os.path.join('logs', f'{cfg.dataset}', f'{cfg.log_dir}')
    else:
        now = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
        cfg.log_dir = os.path.join('logs',  f'{cfg.dataset}', '%s-%s'%(cfg.model, now))

    return cfg


def load_checkpoint(config, model, optimizer, scheduler):
    checkpoint = torch.load(os.path.join(config.log_dir, 'checkpoint', 'current.pth'), map_location='cpu')
    config.from_epoch = checkpoint['epoch'] + 1
    model.load_state_dict(checkpoint['model'])
    optimizer.load_state_dict(checkpoint['optimizer'])
    scheduler.load_state_dict(checkpoint['scheduler'])

    logger.info("=> loaded successfully '{}/checkpoint/current.pth' (epoch {})".format(config.log_dir, checkpoint['epoch']+1))

    del checkpoint
    torch.cuda.empty_cache()


def save_checkpoint(config, epoch, model, optimizer, scheduler):
    logger.info('==> Saving...')
    os.makedirs(os.path.join(config.log_dir, 'checkpoint'), exist_ok=True)

    state = {
        'config': config,
        'model': model.state_dict(),
        'optimizer': optimizer.state_dict(),
        'scheduler': scheduler.state_dict(),
        'epoch': epoch,
    }
    torch.save(state, os.path.join(config.log_dir, 'checkpoint', 'current.pth'))
    logger.info("Saved in {}".format(os.path.join(config.log_dir, 'checkpoint', f'ckpt_epoch_{epoch}.pth')))


def main(config):
    logger.info(config)

    if config.dataset == 'cath_decoys':
        # from datasets.cath_decoys.protein_dataset import get_dataset
        from datasets.cath_decoys.dataset_smote import get_dataset
    else:
        raise NotImplementedError
    
    # config.
    # dataloader
    logger.info('Load Dataset...')
    dataset = get_dataset(config, logger)
    dataset.init_pipeline()
    dataset.init_trainloader()
    dataset.init_valloader()

    train_data_loader = dataset.train_data_loader
    val_data_loader = dataset.val_data_loader

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # model
    logger.info('Load Model...')
    f_model = importlib.import_module('models.' + 'sparseconvunet_point')
    model = f_model.get_model(config).to(device)
    # model = SparseConvUnet_og(config).to(device)
    criterion = f_model.get_loss(config).to(device)

    # if torch.cuda.device_count() > 1:
    #     print("Number of GPUs:", torch.cuda.device_count())
    # ids=[]
    # for i in range(torch.cuda.device_count()):
    #     ids.append(i)
    # print(ids)
    # model = torch.nn.DataParallel(model,device_ids=ids).to(device)


    logger.info("#model parameters {}".format(sum(x.numel() for x in model.parameters())))

    # backup codes
    # backup_files(config)

    # optimizer
    if config.optimizer == 'adam':
        optimizer = optim.Adam(
            model.parameters(),
            lr=config.learning_rate,
            weight_decay=config.weight_decay
        )
    elif config.optimizer == 'sgd':
        optimizer = optim.SGD(
            model.parameters(),
            lr=config.learning_rate,
            momentum=config.momentum,
            weight_decay=config.weight_decay
        )
    elif config.optimizer == 'adamW':
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=config.learning_rate,
            weight_decay=config.weight_decay
        )
    else:
        raise NotImplementedError

    # scheduler
    scheduler = get_scheduler(optimizer, config)

    # load model
    try:
        load_checkpoint(config, model, optimizer, scheduler)
    except:
        logger.info("Training model from scratch...")


    AUC_best = 0
    for epoch in range(config.from_epoch, config.nepoch):
        logger.info('')
        logger.info('======>>>>> Online epoch: #%d, lr=%f <<<<<======' % (epoch+1, scheduler.get_lr()[0]))
        model.train()
        evaluator = evaluators(config)
        output_l = []
        label_l = []
        predict_auc = []
        label_auc = []
        with tqdm(total=len(train_data_loader)) as pbar:
            for data in train_data_loader:
                # torch.cuda.synchronize()
                # tess = torch((data['reg_labels']))
                for k in data.keys():
                    if k in ['features', 'reg_labels']:
                        data[k] = data[k].to(device)
                
                output,batch_label = model(data,device)
                end_points = data
                end_points['residual'] = output
                end_points['batch_label'] = batch_label
                end_points = criterion(end_points,device)
                optimizer.zero_grad()
                
                loss = end_points['loss']
                desc_str,predict_all,label_all = evaluator.add_batch(end_points)

                predict_auc=np.append(predict_auc,np.array(predict_all.detach().cpu().numpy()))
                label_auc=np.append(label_auc,np.array(label_all.detach().cpu().numpy()))

                loss.backward()

                optimizer.step()
                
                # scheduler.step(epoch)
                # torch.cuda.synchronize()

                pbar.set_description(desc_str)
                pbar.update(1)
        scheduler.step(epoch)
        # torch.cuda.synchronize()
        print('total_num' , len(train_data_loader))
        evaluator.print_batch_metric(logger, epoch, len(train_data_loader),predict_auc,label_auc )
        # AUC = evaluator.print_batch_metric(logger, epoch, len(train_data_loader))
        del evaluator

        save_checkpoint(config, epoch, model, optimizer, scheduler)
        # logger.info('Save model...')

        evaluator = evaluators(config)
        model.eval()

        for data in val_data_loader:
            # torch.cuda.synchronize()

            for k in data.keys():
                if k in ['features', 'reg_labels']:
                    data[k] = data[k].to(device)

            output,batch_label = model(data,device)
            end_points = data
            end_points['residual'] = output
            end_points['batch_label'] = batch_label
            end_points = criterion(end_points,device)
            evaluator.add_batch(end_points)
            del end_points
    
        AUC = evaluator.print_batch_metric(logger, epoch, len(val_data_loader),predict_auc,label_auc , 'Validation')
        # evaluator.print_batch_metric(logger, epoch, len(val_data_loader),predict_auc,label_auc , 'Validation')
        if AUC > AUC_best:
            torch.save(model.state_dict(), './ProteinDecoy-main/models/attention_model.pkl')
        AUC_best = AUC
        del evaluator
        # if epoch > 20:
            # torch.save(model.state_dict(), '/nvme/xusheng1/Linglin/resource/ProteinDecoy-main/models/attention_model.pkl')

    # logger.info("End.")

if __name__ == "__main__":
    config = parse_config()
    torch.set_num_threads(6)
    torch.backends.cudnn.enabled = True
    torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.deterministic = True

    os.makedirs(config.log_dir, exist_ok=True)
    os.environ["JOB_LOG_DIR"] = config.log_dir
    # os.environ["CUDA_VISIBLE_DEVICES"] = ','.join(map(str, config.gpu))
    os.environ["CUDA_VISIBLE_DEVICES"] = "1"

    logger = setup_logger(output=config.log_dir, name='%s' % (config.model))

    main(config)
